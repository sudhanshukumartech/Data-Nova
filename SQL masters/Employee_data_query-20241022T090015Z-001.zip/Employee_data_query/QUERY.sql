-- Create the database employee
CREATE DATABASE employees;

-- create table in the emplopyee database
-- Employee table
-- id
-- name
-- position
-- age
use employees;
CREATE TABLE Employee
( ID INT primary KEY,
Name varchar(100),
AGE int,
Position varchar(50)
)


-- check the new created table
SELECT * FROM employee;


-- insert the data into new create table
INSERT INTO employee (id,name,age,position)
values
(1, 'John Doe', 30, 'Software Engineer'), 
(2, 'Jane Smith', 25, 'Data Analyst'), 
(3, 'Sam Johnson', 35, 'Project Manager'),
 (4, 'Emily Davis', 28, 'UX Designer'), 
(5, 'Michael Brown', 45, 'HR Manager'), 
(6, 'Sarah Wilson', 32, 'Marketing Specialist'), 
(7, 'Chris Lee', 29, 'Sales Executive'), 
(8, 'Anna Taylor', 24, 'Junior Developer'), 
(9, 'James Martin', 40, 'DevOps Engineer'), 
(10, 'Olivia White', 27, 'Content Strategist');

-- Data inserted , check the data

Select * From Employee;

-- Update the age 31 of id 1


UPDATE employee
SET age=31
WHERE id =1 ;

-- check the data after updating
SELECT * FROM employee;


-- change the position from HR MANAGER TO HR DIRECTOR AND AGE FROM 32 TO 35 

UPDATE employee
SET age=35 , position='HR Director'
WHERE ID =5;

-- check the data after updating
SELECT * FROM employee;


-- Alter
-- add new columns email in the employee table

ALTER TABLE employee
ADD Email varchar(100);

-- check the table after adding the new column

SELECT * FROM employee;

-- change the column name from NAME TO Employee_name
ALTER TABLE Employee
RENAME COLUMN name to Employee_Name;

-- Change the data type of age from int to tinyint

ALTER TABLE Employee
MODIFY COLUMN age TINYINT;

-- CHANGE THE NAME OF THE TABLE FROM EMPLOYEE TO STAFF

ALTER TABLE Employee
RENAME TO staff;


select * from staff;


-- Delete

DELETE FROM Staff
where id=1;


DELETE FROM Staff
where id in (2,3) ;


-- TRUNCATE
TRUNCATE TABLE Staff;

SELECT * FROM Staff;

-- DROP 

DROP TABLE STAFF;-- DELETE THE TABLE FROM THE DATABASE;

-- Drop the database itself.
DROP DATABASE Employees;






